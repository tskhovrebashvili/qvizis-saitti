from flask import Flask, redirect, render_template, request, abort, url_for
# from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)

@app.route('/home')
def user():
    return render_template('base.html')

@app.route('/football')
def football():
    return render_template('football.html')

@app.route('/basketball')
def basketball():
    return render_template('basketball.html')

@app.route('/rugby')
def rugby():
    return render_template('rugby.html')

@app.route('/baseball')
def baseball():
    return render_template('baseball.html')

@app.route('/ufc')
def UFC():
    return render_template('ufc.html')

@app.route('/login', methods=['POST', 'GET'])
def login():
    if request.method == 'POST':
        return 'თქვენ წარმატებით გაიარეთ ავტორიზაცია'
    return render_template('login.html')

if __name__ == '__main__':
    app.run(debug=True)



#
# app = Flask(__name__)
# app.config['SECRET_KEY'] = 'your_secret_key'
# app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///sports.db'
# db = SQLAlchemy(app)
# @app.route('/')
# def index():
#     return redirect(url_for('login'))
#
# @app.route('/login')
# def login():
#     abort(401)
#     this_is_never_executed()


# def add_sport():
#     if request.method == 'POST':
#         name = request.form['name']
#         description = request.form['description']
#         player_count = request.form['player_count']
#
#         new_sport = Sport(name=name, description=description, player_count=player_count)
#         db.session.add(new_sport)
#         db.session.commit()
#         flash('Sport added successfully!')
#         return redirect(url_for('index'))
#
#     return render_template('add_sport.html')